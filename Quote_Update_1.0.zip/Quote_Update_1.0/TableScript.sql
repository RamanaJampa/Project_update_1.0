

create table userrole(username varchar2(20) primary key,password varchar2(12),rolecode varchar2(10));


create table accounts(accountnumber number(10) primary key,insuredname varchar2(30),insuredstreet varchar2(40),insuredcity varchar2(15),insuredstate varchar2(15),insuredzip varchar2(8),businesssegment varchar2(30),username varchar2(20),constraint fk_username foreign key(username) REFERENCES userrole(username));


create table policy(policynumber number(10) primary key,policypremium number(10,2),accountnumber number(10), constraint fk_policyaccountnumber foreign key(accountnumber) REFERENCES accounts(accountnumber));


create table policydetails(policynumber number(10), questionid varchar2(15),answer varchar2(30), constraint fk_policynumber foreign key(policynumber) references policy(policynumber));


create table business_segment(bus_seg_id number(10),bus_seg_name varchar2(20));


create table policy_questions(pol_ques_id number(10) primary key,bus_seg_id number(10),pol_ques_desc varchar2(80),pol_ques_ans1 varchar2(30),pol_ques_ans1_weightage number(5),pol_ques_ans2 varchar2(30),pol_ques_ans2_weightage number(5),pol_ques_ans3 varchar2(30),pol_ques_ans3_weightage number(5));

alter table accounts add agentid number(10);