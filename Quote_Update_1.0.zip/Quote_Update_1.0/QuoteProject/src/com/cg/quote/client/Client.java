package com.cg.quote.client;

import java.io.IOException;
import java.util.Scanner;

import com.cg.quote.bean.CreateAccount;
import com.cg.quote.bean.NewPolicySchemeBean;
import com.cg.quote.bean.CreateAccount.role;
import com.cg.quote.service.CreateAccountServImpl;
import com.cg.quote.service.ICreateAccountServ;

public class Client {
	static Scanner scanner=new Scanner(System.in);
	static CreateAccount createBean=null;
	static ICreateAccountServ createAccServ=null;
	static String userName=null;
	static String password=null;
	public static void main(String[] args) throws IOException {
	
		//System.out.println("*****Welcome Admin*****");
		
		createBean=new CreateAccount();
		createAccServ=new CreateAccountServImpl();
		
		System.out.println("Enter Username ");
		
		userName = scanner.next();
		createBean.setUsername(userName);
		System.out.println("Enter Password ");
		
		password = scanner.next();
		createBean.setPassword(password);
		CreateAccount.role roleCode;
		System.out.println("Enter Role Code ");
		roleCode = role.valueOf(scanner.next());
		createBean.setRole_code(roleCode);
	
		createAccServ.validateBean(createBean);
		createAccServ.createAccount(createBean);
		
		
		
		System.out.println("Welcome Admin");
		System.out.println("New Scheme Creation Page");
		NewPolicySchemeBean newPolicySchemeBean=new NewPolicySchemeBean();
		System.out.println("Enter New Policy Business Segment ID");
		newPolicySchemeBean.setBus_seg_id(scanner.nextInt());
		System.out.println("Enter New Policy Business Segment Name");
		newPolicySchemeBean.setBus_seg_name(scanner.nextLine());
		System.out.println("Enter New Policy Question ID");
		newPolicySchemeBean.setPol_ques_id(scanner.nextInt());
		System.out.println("Enter New Question ");
		newPolicySchemeBean.setPol_ques_desc(scanner.nextLine());
		System.out.println("Enter Answer-1 For Entered Question:");
		newPolicySchemeBean.setPol_ques_ans1(scanner.nextLine());
		System.out.println("Enter Weightage for Answer-1 :");
		newPolicySchemeBean.setPol_ques_ans1_weightage(scanner.nextInt());
		System.out.println("Enter Answer-2 For Entered Question:");
		newPolicySchemeBean.setPol_ques_ans2(scanner.nextLine());
		System.out.println("Enter Weightage for Answer-2 :");
		newPolicySchemeBean.setPol_ques_ans2_weightage(scanner.nextInt());
		System.out.println("Enter Answer-3 For Entered Question:");
		newPolicySchemeBean.setPol_ques_ans3(scanner.nextLine());
		System.out.println("Enter Weightage for Answer-3 :");
		newPolicySchemeBean.setPol_ques_ans3_weightage(scanner.nextInt());
		
		createAccServ.createNewScheme(newPolicySchemeBean);
		System.out.println("New Policy Scheme Created Successfully");
	}
}