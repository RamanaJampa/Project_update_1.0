package com.cg.quote.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.quote.bean.CreateAccount;
import com.cg.quote.bean.NewPolicySchemeBean;
import com.cg.quote.dao.CreateAccountDaoImpl;
import com.cg.quote.dao.ICreateAccountDao;

public class CreateAccountServImpl implements ICreateAccountServ{

	static ICreateAccountDao createAccountDao=null;
	@Override
	public void createAccount(CreateAccount createBean) throws IOException {
		
		createAccountDao=new CreateAccountDaoImpl();
		
		CreateAccount createBeanServ=createBean;
		
		createAccountDao.createAccount(createBeanServ);
	}
	
	
	
	
	@Override
	public CreateAccount validateBean(CreateAccount createBean) {
		
		List<String> validationErrors = new ArrayList<String>();
		
		if(!(isValidName(createBean.getUsername())))
		{
			validationErrors.add("\n UserName Should Be In Alphabets And Minimum 3 Character Long \n");
		}
		
		if(!(isValidpassword(createBean.getPassword())))
		{
			validationErrors.add("\n Password Should be Minimum 3 Characters \n");
		}
		
	
		if(validationErrors.isEmpty())
		{
			return createBean;
		}
		else
		{
			return null;
		}
	}	
		private boolean isValidName(String username) {
		
			Pattern namePattern = Pattern.compile("^[A-Za-z]{3,}$");
			Matcher nameMatcher = namePattern.matcher(username);
			return nameMatcher.matches();
		}
		
		private boolean isValidpassword(String password) {
			
			Pattern namePattern = Pattern.compile("^[A-Za-z]{3,}$");
			Matcher nameMatcher = namePattern.matcher(password);
			return nameMatcher.matches();
		}




		@Override
		public void createNewScheme(NewPolicySchemeBean newPolicySchemeBean) throws IOException {
			
			createAccountDao.createNewScheme(newPolicySchemeBean);
			
		}

}
