package com.cg.quote.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.quote.bean.CreateAccount;
import com.cg.quote.bean.CreateAccount.role;
import com.cg.quote.bean.NewPolicySchemeBean;
import com.cg.quote.exception.UserNameException;
import com.cg.quote.util.DBConnection;

public class CreateAccountDaoImpl implements ICreateAccountDao{

	@Override
	public void createAccount(CreateAccount createbean) throws IOException {
		
		Connection connection= DBConnection.getConnection();
		
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		try
		{
				ps=connection.prepareStatement("insert into userrole values(?,?,?)");
				role roleCode = createbean.getRole_code();
				ps.setString(1,createbean.getUsername());
				ps.setString(2,createbean.getPassword());
				ps.setString(3,roleCode.name());
				ps.executeUpdate();
				System.out.println("Inserted");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

	@Override
	public void createNewScheme(NewPolicySchemeBean newPolicySchemeBean) throws IOException {
		
		Connection connection= DBConnection.getConnection();
		
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		try
		{
				ps=connection.prepareStatement("insert into business_segment values(?,?)");
				ps.setInt(1,newPolicySchemeBean.getBus_seg_id());
				ps.setString(2,newPolicySchemeBean.getBus_seg_name());
				ps.executeUpdate();
				System.out.println("Inserted into Business_Segement Table");
				PreparedStatement ps_pol_stat=connection.prepareStatement("insert into policy_questions values(?,?,?,?,?,?,?,?,?)");
				ps_pol_stat.setInt(1,newPolicySchemeBean.getPol_ques_id());
				ps_pol_stat.setInt(2,newPolicySchemeBean.getBus_seg_id());
				ps_pol_stat.setString(3,newPolicySchemeBean.getPol_ques_desc());
				ps_pol_stat.setString(4,newPolicySchemeBean.getPol_ques_ans1());
				ps_pol_stat.setInt(5,newPolicySchemeBean.getPol_ques_ans1_weightage());
				ps_pol_stat.setString(6,newPolicySchemeBean.getPol_ques_ans2());
				ps_pol_stat.setInt(7,newPolicySchemeBean.getPol_ques_ans2_weightage());
				ps_pol_stat.setString(8,newPolicySchemeBean.getPol_ques_ans3());
				ps_pol_stat.setInt(9,newPolicySchemeBean.getPol_ques_ans3_weightage());
				ps_pol_stat.executeUpdate();
				System.out.println("Inserted into Policy_Ques Table");
				
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
}
